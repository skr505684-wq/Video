// public/voiceover.srt থেকে src/cues.ts বানায়। চালান: npm run cues
import fs from "node:fs";
const raw = fs.readFileSync("public/voiceover.srt", "utf8").replace(/\r/g, "").trim();
const ts = (s) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4].padEnd(3, "0").slice(0, 3) * 1;
};
const cues = raw.split(/\n\s*\n/).map((blk) => {
  const lines = blk.split("\n");
  const [a, b] = lines[1].split("-->");
  return {
    index: +lines[0],
    startMs: ts(a),
    endMs: ts(b),
    text: lines.slice(2).join(" ").replace(/\s+/g, " ").trim(),
  };
});
const out = `// স্বয়ংক্রিয়ভাবে তৈরি (scripts/srt-to-cues.mjs), হাতে বদলাবেন না।
export type Cue = { index: number; startMs: number; endMs: number; text: string };
export const cues: Cue[] = ${JSON.stringify(cues, null, 2)};
`;
fs.writeFileSync("src/cues.ts", out);
console.log(cues);
