# ক্লিন UI-ধাঁচের ছোট SFX সিন্থেসাইজ করে public/sfx/*.wav ও src/sfxMeta.ts বানায়।
# চালান: python3 scripts/make_sfx.py   (শুধু numpy লাগে)
import numpy as np, wave, os, json
SR = 48000
rng = np.random.default_rng(7)
T = lambda d: np.arange(int(SR * d)) / SR

def lowpass(x, fc):
    a = 1 - np.exp(-2 * np.pi * fc / SR); y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x):
        s += a * (v - s); y[i] = s
    return y

def highpass(x, fc): return x - lowpass(x, fc)

def svf_bandpass(x, fc, q=1.4):
    low = band = 0.0; out = np.zeros_like(x)
    for i in range(len(x)):
        f = 2 * np.sin(np.pi * min(fc[i], SR * 0.45) / SR)
        low += f * band
        high = x[i] - low - band / q
        band += f * high
        out[i] = band
    return out

def reverb(x, wet=1.0):
    y = x.copy()
    for d, g in [(0.011, 0.16), (0.019, 0.11), (0.031, 0.07)]:
        n = int(d * SR); y[n:] += g * wet * x[:-n]
    return y

def finish(x, lp=8000, tail_fade=0.012):
    x = lowpass(x, lp); x = reverb(x)
    n = int(tail_fade * SR); x[-n:] *= np.linspace(1, 0, n) ** 2
    x[:16] *= np.linspace(0, 1, 16)
    return x

def pop():
    t = T(0.2); f = 150 + 560 * np.exp(-t * 30)
    ph = 2 * np.pi * np.cumsum(f) / SR
    env = np.minimum(t / 0.004, 1) * np.exp(-t / 0.05)
    return finish((np.sin(ph) + 0.15 * np.sin(2 * ph)) * env, 7000)

def click():
    t = T(0.09)
    n = highpass(rng.standard_normal(len(t)), 2500) * np.exp(-t / 0.007)
    tone = np.sin(2 * np.pi * 2400 * t) * np.exp(-t / 0.004) * 0.25
    return finish(n * 0.5 + tone, 9000, 0.01)

def whoosh():
    t = T(0.6); n = rng.standard_normal(len(t))
    fc = 350 * (2800 / 350) ** (t / 0.6)
    env = np.sin(np.pi * np.clip(t / 0.6, 0, 1)) ** 2.2
    return finish(svf_bandpass(n, fc, 1.2) * env, 6500)

def swipe():
    t = T(0.4); n = rng.standard_normal(len(t))
    fc = 800 * (4200 / 800) ** (t / 0.4)
    env = np.sin(np.pi * np.clip(t / 0.4, 0, 1)) ** 2
    return finish(svf_bandpass(n, fc, 1.4) * env, 7500)

def chime():
    t = T(0.55); y = np.zeros(len(t))
    for f, a, d in [(880, 1, .18), (1318.5, .5, .14), (1760, .3, .10), (2637, .12, .07)]:
        for det in (1.0, 1.003):
            y += a * 0.5 * np.sin(2 * np.pi * f * det * t) * np.exp(-t / d)
    y *= np.minimum(t / 0.006, 1)
    return finish(y, 7000)

def thud():
    t = T(0.35); f = 46 + 36 * np.exp(-t * 18)
    ph = 2 * np.pi * np.cumsum(f) / SR
    env = np.minimum(t / 0.008, 1) * np.exp(-t / 0.11)
    return finish((np.sin(ph) + 0.25 * np.sin(2 * ph)) * env, 600)

sounds = {"pop": pop, "click": click, "whoosh": whoosh, "swipe": swipe, "chime": chime, "thud": thud}
TARGET_RMS_DB, PEAK_MAX = -20.0, 0.9
os.makedirs("public/sfx", exist_ok=True); meta = {}
for name, fn in sounds.items():
    x = fn()
    rms = np.sqrt(np.mean(x ** 2)); g = 10 ** (TARGET_RMS_DB / 20) / rms
    g = min(g, PEAK_MAX / np.max(np.abs(x))); x = x * g
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(f"public/sfx/{name}.wav", "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    peak = float(np.max(np.abs(x))); rmsdb = float(20 * np.log10(np.sqrt(np.mean(x ** 2))))
    clip = int(np.sum(np.abs(pcm) >= 32767))
    meta[name] = {"dur": round(len(x) / SR, 3)}
    print(f"{name:7s} dur={len(x)/SR:.2f}s peak={peak:.2f} ({20*np.log10(peak):.1f} dBFS) rms={rmsdb:.1f} dBFS clipped={clip}")
vol = {"thud": .28, "whoosh": .24, "swipe": .26, "pop": .30, "click": .30, "chime": .24}
ts = "// স্বয়ংক্রিয়ভাবে তৈরি (scripts/make_sfx.py)\nexport const sfxMeta = " + json.dumps(
    {k: {"file": f"sfx/{k}.wav", "dur": v["dur"], "vol": vol[k]} for k, v in meta.items()}, indent=2) + " as const;\n"
open("src/sfxMeta.ts", "w").write(ts)
