// স্বয়ংক্রিয়ভাবে তৈরি (scripts/srt-to-cues.mjs), হাতে বদলাবেন না।
export type Cue = { index: number; startMs: number; endMs: number; text: string };
export const cues: Cue[] = [
  {
    "index": 1,
    "startMs": 100,
    "endMs": 4420,
    "text": "একটা কথা জানো? তোমার এই ভুলটাই তোমাকে পিছিয়ে রাখছে। তুমি ভাবছো কাল থেকে শুরু"
  },
  {
    "index": 2,
    "startMs": 4420,
    "endMs": 8900,
    "text": "করবে। কিন্তু মনে রেখো, তোমার কাল কখনো আসবে না যদি আজ শুরু না কর। আজই শুরু কর। আর"
  },
  {
    "index": 3,
    "startMs": 8900,
    "endMs": 11020,
    "text": "কথাটা সত্যি মনে হলে video টা share কর।"
  }
];
