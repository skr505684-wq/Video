import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {theme} from './theme';
import {BgMesh, Grade, Grain, Vignette} from './components/Backdrop';
import {SfxLayer} from './components/Sfx';
import {PreviewAudio} from './components/PreviewAudio';
import {HookScene} from './scenes/HookScene';
import {SplitScene} from './scenes/SplitScene';
import {CtaScene} from './scenes/CtaScene';
import {sceneDur, sceneFrom} from './plan';

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
    <BgMesh />
    <Sequence from={sceneFrom[0]} durationInFrames={sceneDur[0]}>
      <HookScene />
    </Sequence>
    <Sequence from={sceneFrom[1]} durationInFrames={sceneDur[1]}>
      <SplitScene />
    </Sequence>
    <Sequence from={sceneFrom[2]} durationInFrames={sceneDur[2]}>
      <CtaScene />
    </Sequence>
    <Grade />
    <Grain />
    <Vignette />
    <SfxLayer />
    <PreviewAudio />
  </AbsoluteFill>
);
