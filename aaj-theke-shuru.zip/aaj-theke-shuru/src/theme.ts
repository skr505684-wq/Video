// theme.ts: রং, ইজিং, spring প্রিসেট ও ফন্ট একমাত্র এখানে। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// স্কিম: "মধ্যরাত ও সোনা"
import {Easing} from 'remotion';
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

const {fontFamily} = loadFont('normal', {
  weights: ['500', '700'],
  subsets: ['bengali', 'latin'],
});

const colors = {
  bg: '#0B1220',
  bgAlt: '#111B30',
  primary: '#3B82F6', // হিরো: প্রতি ফ্রেমে সর্বোচ্চ একটি এলিমেন্টে
  primarySoft: '#93C5FD',
  accent: '#FBBF24',
  accentSoft: '#FDE68A',
  text: '#F8FAFC',
  textDim: '#94A3B8',
  glow: 'rgba(59, 130, 246, 0.45)',
  accentGlow: 'rgba(251, 191, 36, 0.35)',
  surface: 'rgba(248, 250, 252, 0.06)',
  surfaceStrong: 'rgba(248, 250, 252, 0.12)',
  border: 'rgba(248, 250, 252, 0.14)',
  shadow: 'rgba(2, 6, 23, 0.7)',
  black: '#000000',
} as const;

export const theme = {
  colors,
  gradients: {
    hero: `linear-gradient(100deg, ${colors.primarySoft}, ${colors.primary})`,
    gold: `linear-gradient(100deg, ${colors.accentSoft}, ${colors.accent})`,
    heroFill: `linear-gradient(90deg, ${colors.primary}, ${colors.primarySoft})`,
    goldFill: `linear-gradient(90deg, ${colors.accent}, ${colors.accentSoft})`,
  },
  fonts: {display: `${fontFamily}, sans-serif`},
  weight: {bold: 700, medium: 500},
  radius: {card: 40, pill: 999},
  shadow: {card: `0 40px 80px -24px ${colors.shadow}`},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;

export type SpringName = keyof typeof theme.spring;
