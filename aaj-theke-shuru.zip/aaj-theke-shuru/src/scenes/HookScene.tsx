import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {Beat, SceneShell} from '../components/Structure';
import {Pop, Words, glass} from '../components/Anim';
import {hook, sceneDur} from '../plan';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// বিট A: কাইনেটিক হুক "একটা কথা জানো?" + প্রসারিত রিং
const HookA: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        {[0, 1, 2].map((i) => {
          const f = frame - i * 12;
          if (f < 0) return null;
          const ph = (f % 44) / 44;
          return (
            <circle
              key={i}
              cx={960}
              cy={540}
              r={170 + ph * 560}
              fill="none"
              stroke={theme.colors.primary}
              strokeWidth={3}
              opacity={(1 - ph) * 0.35}
            />
          );
        })}
      </svg>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          rowGap: 6,
        }}
      >
        <Words tokens={[{t: 'একটা'}, {t: 'কথা'}]} size={150} per={3} justify="center" />
        <Words tokens={[{t: 'জানো?', kind: 'hero', pop: true}]} size={270} delay={8} justify="center" />
      </div>
    </>
  );
};

const Headline: React.FC = () => (
  <div style={{position: 'absolute', left: 130, top: 0, bottom: 0, width: 890, display: 'flex', alignItems: 'center'}}>
    <Words
      tokens={[
        {t: 'তোমার'},
        {t: 'এই'},
        {t: 'ভুলটাই', hl: true},
        {t: 'তোমাকে'},
        {t: 'পিছিয়ে'},
        {t: 'রাখছে।'},
      ]}
      size={106}
      per={4}
      maxWidth={890}
    />
  </div>
);

const Dots: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'flex', columnGap: 14, marginTop: 6, paddingLeft: 10}}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            width: 18,
            height: 18,
            borderRadius: '50%',
            background: theme.colors.textDim,
            opacity: 0.55 + Math.sin(frame / 6 - i * 0.9) * 0.4,
            transform: `translateY(${Math.sin(frame / 6 - i * 0.9) * -5}px)`,
          }}
        />
      ))}
    </div>
  );
};

// বিট C: "কাল থেকে শুরু…" চিন্তার কার্ড
const Thought: React.FC = () => {
  const frame = useCurrentFrame();
  const float = Math.sin(frame / 30) * 4;
  return (
    <div style={{position: 'absolute', left: 130, top: 0, bottom: 0, width: 890, display: 'flex', alignItems: 'center'}}>
      <Pop delay={0} y={60}>
        <div style={{...glass({padding: '40px 60px 34px', borderRadius: 60}), transform: `translateY(${float}px)`}}>
          <Words tokens={[{t: 'কাল', kind: 'gold'}, {t: 'থেকে'}, {t: 'শুরু…'}]} size={124} per={5} />
          <Dots />
        </div>
      </Pop>
    </div>
  );
};

const TRACK_W = 634;
const lanes = [
  {top: 74, target: 0.92, delay: 8, you: false},
  {top: 188, target: 0.74, delay: 14, you: false},
  {top: 344, target: 0.1, delay: 0, you: true},
] as const;

// মূল ভিজ্যুয়াল: রেস ট্র্যাক। অন্যরা এগোয়, "তুমি" আটকে আছে।
const RaceTrack: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const card = spring({frame: frame - 2, fps, config: theme.spring.smooth});
  return (
    <div
      style={{
        position: 'absolute',
        left: 1060,
        top: 250,
        width: 730,
        height: 560,
        opacity: Math.min(1, card * 1.4),
        transform: `translateX(${interpolate(card, [0, 1], [90, 0])}px) scale(${interpolate(card, [0, 1], [0.94, 1])})`,
      }}
    >
      <div style={{...glass(), position: 'absolute', inset: 0}} />
      <div style={{position: 'absolute', left: 48, top: 48, width: TRACK_W, height: 464}}>
        <div
          style={{
            position: 'absolute',
            left: TRACK_W + 16,
            top: 20,
            height: 424,
            borderLeft: `3px dashed ${theme.colors.textDim}`,
            opacity: 0.45,
          }}
        />
        {lanes.map((ln, i) => {
          const prog = ln.you
            ? 0.1 + Math.sin(frame / 20) * 0.006
            : interpolate(frame - ln.delay, [0, 60], [0, ln.target], {easing: theme.ease.out, ...clamp});
          const head = prog * (TRACK_W - 56);
          const float = Math.sin(frame / 16 + i) * 3;
          const ping = (frame % 42) / 42;
          return (
            <div key={i} style={{position: 'absolute', left: 0, top: ln.top, width: TRACK_W, height: 56}}>
              {ln.you ? (
                <div
                  style={{
                    position: 'absolute',
                    top: -70,
                    left: 0,
                    fontFamily: theme.fonts.display,
                    fontWeight: theme.weight.bold,
                    fontSize: 44,
                    lineHeight: 1.3,
                    letterSpacing: 0,
                    color: theme.colors.text,
                  }}
                >
                  তুমি
                </div>
              ) : null}
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  top: 17,
                  width: TRACK_W,
                  height: 22,
                  borderRadius: 11,
                  background: theme.colors.surfaceStrong,
                }}
              />
              <div
                style={{
                  position: 'absolute',
                  left: 0,
                  top: 17,
                  width: head + 28,
                  height: 22,
                  borderRadius: 11,
                  background: ln.you ? theme.gradients.heroFill : theme.gradients.goldFill,
                  opacity: ln.you ? 1 : 0.85,
                }}
              />
              {ln.you ? (
                <div
                  style={{
                    position: 'absolute',
                    left: head,
                    top: 0,
                    width: 56,
                    height: 56,
                    borderRadius: '50%',
                    border: `3px solid ${theme.colors.primary}`,
                    opacity: (1 - ping) * 0.6,
                    transform: `scale(${1 + ping * 0.9})`,
                  }}
                />
              ) : null}
              <div
                style={{
                  position: 'absolute',
                  left: head,
                  top: float,
                  width: 56,
                  height: 56,
                  borderRadius: '50%',
                  background: ln.you ? theme.gradients.heroFill : theme.gradients.goldFill,
                  border: `3px solid ${theme.colors.text}`,
                  boxShadow: ln.you
                    ? `0 0 40px ${theme.colors.glow}, 0 0 90px ${theme.colors.glow}`
                    : `0 10px 24px ${theme.colors.shadow}`,
                  transform: `scale(${ln.you ? 1 + Math.sin(frame / 12) * 0.04 : 1})`,
                }}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const HookScene: React.FC = () => {
  const D = sceneDur[0];
  return (
    <SceneShell first>
      <Beat from={0} to={hook.B}>
        <HookA />
      </Beat>
      <Beat from={hook.B} to={hook.C}>
        <Headline />
      </Beat>
      <Beat from={hook.C} to={D} exit={false}>
        <Thought />
      </Beat>
      <Beat from={hook.B} to={D} exit={false}>
        <RaceTrack />
      </Beat>
    </SceneShell>
  );
};
