import React from 'react';
import {Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/Structure';
import {Words} from '../components/Anim';
import {ShareIcon} from '../components/Icons';
import {cta} from '../plan';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const font = {
  fontFamily: theme.fonts.display,
  fontWeight: theme.weight.bold,
  letterSpacing: 0,
  lineHeight: 1.3,
} as const;

// ছবির কার্ড: এন্ট্রি স্প্রিং + Ken Burns
const PhotoCard: React.FC<{
  src: string;
  w: number;
  h: number;
  left: number;
  top: number;
  rot: number;
  delay: number;
  pos: string;
  dir: 1 | -1;
}> = ({src, w, h, left, top, rot, delay, pos, dir}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring.smooth});
  const kb = interpolate(frame, [0, durationInFrames], [dir === 1 ? 1 : 1.1, dir === 1 ? 1.1 : 1], {
    easing: theme.ease.inOut,
    ...clamp,
  });
  const float = Math.sin(frame / 26 + delay) * 4;
  return (
    <div
      style={{
        position: 'absolute',
        left,
        top: top + float,
        width: w,
        height: h,
        borderRadius: theme.radius.card,
        overflow: 'hidden',
        border: `3px solid ${theme.colors.border}`,
        boxShadow: theme.shadow.card,
        opacity: Math.min(1, p * 1.4),
        transform: `translateY(${interpolate(p, [0, 1], [90, 0])}px) rotate(${interpolate(
          p,
          [0, 1],
          [rot - 8, rot],
        )}deg) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
      }}
    >
      <Img
        src={staticFile(src)}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          objectPosition: pos,
          transform: `scale(${kb})`,
          filter: 'saturate(0.92)',
        }}
      />
    </div>
  );
};

const ShareButton: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame: frame - cta.B - 8, fps, config: theme.spring.bouncy});
  const press = spring({frame: frame - cta.press, fps, config: {damping: 9, stiffness: 220, mass: 0.5}});
  const pressScale =
    frame < cta.press
      ? interpolate(frame, [cta.press - 4, cta.press], [1, 0.93], clamp)
      : 0.93 + 0.07 * press;
  const scale = interpolate(enter, [0, 1], [0.6, 1]) * pressScale * (1 + Math.sin(frame / 16) * 0.012);
  const rip = interpolate(frame - cta.press, [0, 20], [0, 1], {easing: theme.ease.out, ...clamp});
  return (
    <div style={{position: 'relative', opacity: Math.min(1, enter * 1.4), transform: `scale(${scale})`}}>
      {frame >= cta.press ? (
        <div
          style={{
            position: 'absolute',
            inset: -4,
            borderRadius: theme.radius.pill,
            border: `4px solid ${theme.colors.primarySoft}`,
            opacity: (1 - rip) * 0.7,
            transform: `scale(${1 + rip * 0.35})`,
          }}
        />
      ) : null}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          columnGap: 22,
          padding: '10px 54px 10px 44px',
          borderRadius: theme.radius.pill,
          background: theme.gradients.heroFill,
          boxShadow: `0 0 50px ${theme.colors.glow}, 0 0 110px ${theme.colors.glow}`,
          ...font,
          fontSize: 116,
          color: theme.colors.text,
        }}
      >
        <ShareIcon size={88} color={theme.colors.text} />
        share
      </div>
    </div>
  );
};

export const CtaScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const kor = spring({frame: frame - cta.B - 14, fps, config: theme.spring.snappy});
  return (
    <SceneShell last>
      <PhotoCard
        src="assets/photo-portrait.jpg"
        w={420}
        h={560}
        left={150}
        top={170}
        rot={-6}
        delay={6}
        pos="center 22%"
        dir={1}
      />
      <PhotoCard
        src="assets/photo-square.jpg"
        w={370}
        h={370}
        left={420}
        top={500}
        rot={5}
        delay={11}
        pos="center 30%"
        dir={-1}
      />
      <div
        style={{
          position: 'absolute',
          left: 930,
          top: 0,
          bottom: 0,
          width: 900,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          rowGap: 10,
        }}
      >
        <Words
          tokens={[{t: 'কথাটা', kind: 'dim'}, {t: 'সত্যি', kind: 'dim'}, {t: 'মনে', kind: 'dim'}, {t: 'হলে', kind: 'dim'}]}
          size={78}
          per={4}
        />
        <Words tokens={[{t: 'video'}, {t: 'টা'}]} size={150} delay={cta.B} per={4} />
        <div style={{display: 'flex', alignItems: 'center', columnGap: 36}}>
          <ShareButton />
          <div
            style={{
              ...font,
              fontSize: 150,
              color: theme.colors.text,
              opacity: Math.min(1, kor * 1.5),
              transform: `translateY(${interpolate(kor, [0, 1], [40, 0])}px)`,
            }}
          >
            কর
          </div>
        </div>
      </div>
    </SceneShell>
  );
};
