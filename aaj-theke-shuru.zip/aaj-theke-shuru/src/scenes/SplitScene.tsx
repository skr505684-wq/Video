import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {Beat, SceneShell} from '../components/Structure';
import {Pop, Words, glass} from '../components/Anim';
import {CalendarIcon, SunIcon} from '../components/Icons';
import {split} from '../plan';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const PANEL = {top: 200, width: 830, height: 720};
const font = {
  fontFamily: theme.fonts.display,
  fontWeight: theme.weight.bold,
  letterSpacing: 0,
  lineHeight: 1.3,
} as const;

// বাম প্যানেল: "কাল", ক্যালেন্ডার ফিকে হয়, কাটা পড়ে, কণা উড়ে যায়
const LeftPanel: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - 4, fps, config: theme.spring.smooth});
  const b2 = interpolate(frame, [split.B2, split.B2 + 16], [0, 1], {easing: theme.ease.out, ...clamp});
  const b3 = interpolate(frame, [split.B3, split.B3 + 14], [0, 1], {easing: theme.ease.inOut, ...clamp});
  const dim = 1 - b2 * 0.45 - b3 * 0.3;
  const strike = interpolate(frame, [split.B2, split.B2 + 12], [0, 1], {easing: theme.ease.out, ...clamp});
  return (
    <div
      style={{
        position: 'absolute',
        left: 80,
        top: PANEL.top,
        width: PANEL.width,
        height: PANEL.height,
        opacity: Math.min(1, p * 1.4),
        transform: `translateX(${interpolate(p, [0, 1], [-140, 0])}px)`,
      }}
    >
      <div style={{...glass(), position: 'absolute', inset: 0}} />
      {Array.from({length: 14}).map((_, i) => {
        const x = 120 + ((i * 97) % 600);
        const y0 = 220 + ((i * 53) % 300);
        const t = Math.max(0, frame - split.B2 - (i % 5) * 2);
        const rise = interpolate(t, [0, 60], [0, 160 + (i % 4) * 30], {easing: theme.ease.out, ...clamp});
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x + Math.sin(i) * rise * 0.3,
              top: y0 - rise,
              width: 12 + (i % 3) * 5,
              height: 12 + (i % 3) * 5,
              borderRadius: 4,
              background: theme.colors.textDim,
              opacity: t > 0 ? Math.max(0, 0.55 - t / 80) : 0,
              transform: `rotate(${i * 25 + t * 3}deg)`,
            }}
          />
        );
      })}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          rowGap: 14,
          opacity: dim,
          filter: b2 > 0.05 ? `blur(${b2 * 1.4}px)` : undefined,
        }}
      >
        <CalendarIcon size={170} color={theme.colors.textDim} />
        <div style={{position: 'relative'}}>
          <div style={{...font, fontSize: 230, color: theme.colors.textDim}}>কাল</div>
          <div
            style={{
              position: 'absolute',
              left: -20,
              top: '56%',
              height: 12,
              width: 'calc(100% + 40px)',
              borderRadius: 6,
              background: theme.gradients.goldFill,
              transformOrigin: 'left center',
              transform: `scaleX(${strike}) rotate(-4deg)`,
            }}
          />
        </div>
        <div style={{height: 108}}>
          <Words tokens={[{t: 'কখনো'}, {t: 'আসবে'}, {t: 'না'}]} size={84} delay={split.B2 + 6} per={4} justify="center" />
        </div>
      </div>
    </div>
  );
};

// ডান প্যানেল: "আজ" জ্বলে ওঠে (হিরো গ্লো এখানেই)
const RightPanel: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - 8, fps, config: theme.spring.smooth});
  const lit = interpolate(frame, [split.B3, split.B3 + 16], [0, 1], {easing: theme.ease.out, ...clamp});
  const pulse = spring({frame: frame - split.B3, fps, config: theme.spring.bouncy});
  return (
    <div
      style={{
        position: 'absolute',
        left: 1010,
        top: PANEL.top,
        width: PANEL.width,
        height: PANEL.height,
        opacity: Math.min(1, p * 1.4),
        transform: `translateX(${interpolate(p, [0, 1], [140, 0])}px)`,
      }}
    >
      <div style={{...glass(), position: 'absolute', inset: 0}} />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: theme.radius.card,
          border: `3px solid ${theme.colors.primary}`,
          boxShadow: `0 0 60px ${theme.colors.glow}, 0 0 120px ${theme.colors.glow}`,
          opacity: lit,
        }}
      />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          rowGap: 14,
        }}
      >
        <div style={{opacity: 0.3 + lit * 0.7}}>
          <SunIcon size={170} delay={split.B3} />
        </div>
        <div
          style={{
            ...font,
            fontSize: 230,
            color: lit > 0.02 ? theme.colors.text : theme.colors.textDim,
            opacity: 0.3 + lit * 0.7,
            transform: `scale(${interpolate(pulse, [0, 1], [0.9, 1])})`,
          }}
        >
          আজ
        </div>
        <div style={{height: 108}}>
          <Words
            tokens={[{t: 'আজই', hl: true}, {t: 'শুরু'}, {t: 'কর'}]}
            size={84}
            delay={split.B3 + 2}
            per={4}
            justify="center"
          />
        </div>
      </div>
    </div>
  );
};

export const SplitScene: React.FC = () => {
  return (
    <SceneShell>
      <Beat from={0} to={split.B2}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 50, display: 'flex', justifyContent: 'center'}}>
          <Pop delay={2} y={30}>
            <div
              style={{
                ...glass({borderRadius: theme.radius.pill, padding: '8px 46px'}),
                ...font,
                fontSize: 62,
                color: theme.colors.accentSoft,
              }}
            >
              কিন্তু মনে রেখো
            </div>
          </Pop>
        </div>
      </Beat>
      <LeftPanel />
      <RightPanel />
    </SceneShell>
  );
};
