// সব সময়ের হিসাব SRT (src/cues.ts) থেকে। হাতে কোনো ফ্রেম বসানো নেই।
import {cues} from './cues';
import {FPS} from './config';

export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
export const OVERLAP = 10; // সিন ট্রানজিশনের ওভারল্যাপ

export const msToFrame = (ms: number) => Math.round((ms / 1000) * FPS);
export const TOTAL_FRAMES = Math.ceil((cues[cues.length - 1].endMs / 1000) * FPS);

const words = (s: string) => s.trim().split(/\s+/).length;
const norm = (s: string) => s.replace(/\s+/g, ' ').trim();

export type Seg = {start: number; speech: number; end: number};

// একটি cue-কে শব্দসংখ্যার অনুপাতে ভাগ করে; start = speech - LEAD
export const segments = (cueIdx: number, parts: string[]): Seg[] => {
  const c = cues[cueIdx];
  if (norm(parts.join(' ')) !== norm(c.text)) {
    console.warn(`[timing] cue ${cueIdx + 1}-এর টেক্সট SRT-র সাথে মেলে না`);
  }
  const a = msToFrame(c.startMs);
  const b = msToFrame(c.endMs);
  const w = parts.map(words);
  const total = w.reduce((x, y) => x + y, 0);
  let acc = 0;
  return parts.map((_, i) => {
    const speech = a + Math.round((acc / total) * (b - a));
    acc += w[i];
    const end = a + Math.round((acc / total) * (b - a));
    return {start: Math.max(0, speech - LEAD), speech, end};
  });
};

export const sceneStart = (cueIdx: number) =>
  cueIdx === 0 ? 0 : Math.max(0, msToFrame(cues[cueIdx].startMs) - LEAD);
