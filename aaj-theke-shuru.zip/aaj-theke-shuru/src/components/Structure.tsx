import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {OVERLAP} from '../timing';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// সিনের মোড়ক: ঢোকা (স্লাইড + ব্লার + ফেড) ও বেরোনো (দ্রুত)
export const SceneShell: React.FC<{children: React.ReactNode; first?: boolean; last?: boolean}> = ({
  children,
  first,
  last,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const enter = first
    ? 1
    : interpolate(frame, [0, 14], [0, 1], {easing: theme.ease.out, ...clamp});
  const exit = last
    ? interpolate(frame, [durationInFrames - 8, durationInFrames - 1], [0, 1], {
        easing: theme.ease.in,
        ...clamp,
      })
    : interpolate(frame, [durationInFrames - OVERLAP - 1, durationInFrames - 1], [0, 1], {
        easing: theme.ease.in,
        ...clamp,
      });
  const x = (1 - enter) * 150 - (last ? 0 : exit * 150);
  const blur = (1 - enter) * 12 + (last ? 0 : exit * 12);
  return (
    <AbsoluteFill
      style={{
        opacity: enter * (1 - exit),
        transform: `translateX(${x}px)`,
        filter: blur > 0.2 ? `blur(${blur}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const BeatInner: React.FC<{children: React.ReactNode; exit: boolean}> = ({children, exit}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const p = exit
    ? interpolate(frame, [durationInFrames - 9, durationInFrames - 1], [0, 1], {
        easing: theme.ease.in,
        ...clamp,
      })
    : 0;
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - p,
        transform: `translateY(${-p * 40}px) scale(${1 - p * 0.03})`,
        filter: p > 0.02 ? `blur(${p * 6}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

// বিট: নির্দিষ্ট ফ্রেম থেকে দেখায়; exit=true হলে পরের বিটের সাথে ওভারল্যাপে দ্রুত বেরোয়
export const Beat: React.FC<{
  from: number;
  to: number;
  exit?: boolean;
  children: React.ReactNode;
}> = ({from, to, exit = true, children}) => (
  <Sequence from={from} durationInFrames={Math.max(2, to - from + (exit ? OVERLAP : 0))}>
    <BeatInner exit={exit}>{children}</BeatInner>
  </Sequence>
);
