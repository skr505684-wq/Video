import React, {useEffect, useState} from 'react';
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from 'remotion';
import {PREVIEW_VOICEOVER, VOICEOVER_IN_RENDER} from '../config';

// public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ।
// ফ্ল্যাগ: src/config.ts। ডিফল্টে Studio-তে চালু, রেন্ডারে বন্ধ।
export const PreviewAudio: React.FC = () => {
  const enabled =
    PREVIEW_VOICEOVER && (!getRemotionEnvironment().isRendering || VOICEOVER_IN_RENDER);
  const [handle] = useState(() => (enabled ? delayRender('voiceover চেক') : null));
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (!enabled || handle === null) return;
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => {
        const ct = r.headers.get('content-type') ?? '';
        setExists(r.ok && !ct.includes('text/html'));
      })
      .catch(() => setExists(false))
      .finally(() => continueRender(handle));
  }, [enabled, handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile('voiceover.mp3')} volume={1} />;
};
