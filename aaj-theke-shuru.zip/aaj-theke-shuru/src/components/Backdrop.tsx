import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {theme} from '../theme';

// স্তর ১: ব্যাকগ্রাউন্ড মেশ (কখনো ফ্ল্যাট নয়)
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(160deg, ${theme.colors.bgAlt}, ${theme.colors.bg} 60%)`,
      }}
    >
      <div
        style={{
          position: 'absolute',
          width: 1300,
          height: 1300,
          borderRadius: '50%',
          top: -560,
          left: -360 + d1,
          filter: 'blur(50px)',
          background: `radial-gradient(circle, ${theme.colors.primary}38, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          width: 1000,
          height: 1000,
          borderRadius: '50%',
          bottom: -480,
          right: -300 - d2,
          filter: 'blur(70px)',
          background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.textDim}33 1.5px, transparent 1.6px)`,
          backgroundSize: '56px 56px',
          opacity: 0.35,
        }}
      />
    </AbsoluteFill>
  );
};

// কালার গ্রেড (কনটেন্টের উপরে)
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.primary,
        mixBlendMode: 'soft-light',
        opacity: 0.2,
      }}
    />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.colors.black}1A, transparent 28%, transparent 72%, ${theme.colors.black}33)`,
      }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        backgroundImage: noise,
        backgroundSize: '220px',
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: 'overlay',
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: `radial-gradient(ellipse at center, transparent 56%, ${theme.colors.black}47 100%)`,
    }}
  />
);
