import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, SpringName} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// প্রিমিয়াম এন্ট্রি: opacity + উঠে আসা + স্কেল
export const Pop: React.FC<{
  delay?: number;
  y?: number;
  cfg?: SpringName;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({delay = 0, y = 40, cfg = 'smooth', style, children}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring[cfg]});
  return (
    <div
      style={{
        opacity: Math.min(1, p * 1.4),
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(
          p,
          [0, 1],
          [0.94, 1],
        )})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

export type Tok = {
  t: string;
  kind?: 'plain' | 'hero' | 'gold' | 'dim';
  hl?: boolean; // হাইলাইট সুইপ
  pop?: boolean; // বাউন্স পপ
};

// শব্দ ধরে স্ট্যাগার্ড রিভিল। বাংলা: শুধু স্পেসে ভাঙে, অক্ষর ধরে নয়, letterSpacing 0।
export const Words: React.FC<{
  tokens: Tok[];
  size: number;
  delay?: number;
  per?: number;
  justify?: 'flex-start' | 'center';
  maxWidth?: number;
}> = ({tokens, size, delay = 0, per = 4, justify = 'flex-start', maxWidth}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: justify,
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.02),
        maxWidth,
        fontFamily: theme.fonts.display,
        fontWeight: theme.weight.bold,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        color: theme.colors.text,
      }}
    >
      {tokens.map((tk, i) => {
        const d = delay + i * per;
        const p = spring({
          frame: frame - d,
          fps,
          config: tk.pop ? theme.spring.bouncy : theme.spring.snappy,
        });
        const hl = interpolate(frame - d - 5, [0, 12], [0, 1], {
          easing: theme.ease.out,
          ...clamp,
        });
        const kindStyle: React.CSSProperties =
          tk.kind === 'hero'
            ? {
                backgroundImage: theme.gradients.hero,
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
                filter: `drop-shadow(0 0 ${Math.round(size * 0.18)}px ${theme.colors.glow})`,
              }
            : tk.kind === 'gold'
            ? {
                backgroundImage: theme.gradients.gold,
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                color: 'transparent',
              }
            : tk.kind === 'dim'
            ? {color: theme.colors.textDim}
            : {};
        return (
          <span
            key={i}
            style={{
              position: 'relative',
              display: 'inline-block',
              whiteSpace: 'nowrap',
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${interpolate(p, [0, 1], [size * 0.32, 0])}px) scale(${interpolate(
                p,
                [0, 1],
                [tk.pop ? 0.7 : 0.94, 1],
              )})`,
            }}
          >
            {tk.hl ? (
              <span
                style={{
                  position: 'absolute',
                  left: -size * 0.1,
                  right: -size * 0.1,
                  bottom: size * 0.1,
                  height: size * 0.46,
                  borderRadius: size * 0.12,
                  background: `${theme.colors.accent}59`,
                  transformOrigin: 'left center',
                  transform: `scaleX(${hl})`,
                }}
              />
            ) : null}
            <span
              style={{
                position: 'relative',
                display: 'inline-block',
                padding: '0.04em 0.06em',
                ...kindStyle,
              }}
            >
              {tk.t}
            </span>
          </span>
        );
      })}
    </div>
  );
};

export const glass = (extra?: React.CSSProperties): React.CSSProperties => ({
  background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
  border: `2px solid ${theme.colors.border}`,
  borderRadius: theme.radius.card,
  boxShadow: theme.shadow.card,
  ...extra,
});
