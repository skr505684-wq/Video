import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';

export const CalendarIcon: React.FC<{size: number; color: string}> = ({size, color}) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <rect x="6" y="12" width="52" height="46" rx="9" stroke={color} strokeWidth="3.5" />
    <path d="M6 26h52" stroke={color} strokeWidth="3.5" />
    <path d="M20 6v12M44 6v12" stroke={color} strokeWidth="3.5" strokeLinecap="round" />
    {[0, 1, 2].map((r) =>
      [0, 1, 2, 3].map((c) => (
        <rect
          key={`${r}-${c}`}
          x={14 + c * 11}
          y={32 + r * 8.5}
          width="6"
          height="5"
          rx="1.5"
          fill={color}
          opacity={0.7}
        />
      )),
    )}
  </svg>
);

export const ShareIcon: React.FC<{size: number; color: string}> = ({size, color}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.2" strokeLinecap="round">
    <circle cx="18" cy="5" r="3" />
    <circle cx="6" cy="12" r="3" />
    <circle cx="18" cy="19" r="3" />
    <path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" />
  </svg>
);

// সূর্য: গোল + স্ট্যাগার্ড রশ্মি। lit = 0..1
export const SunIcon: React.FC<{size: number; delay: number}> = ({size, delay}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const rays = 12;
  const core = spring({frame: frame - delay, fps, config: theme.spring.bouncy});
  return (
    <div style={{position: 'relative', width: size, height: size}}>
      {Array.from({length: rays}).map((_, i) => {
        const p = spring({frame: frame - delay - 4 - i * 1.2, fps, config: theme.spring.snappy});
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: '50%',
              top: '50%',
              width: size * 0.07,
              height: size * 0.2 * p,
              background: theme.colors.accent,
              borderRadius: size,
              transformOrigin: '50% 0%',
              transform: `translateX(-50%) rotate(${(360 / rays) * i}deg) translateY(${size * 0.3}px)`,
            }}
          />
        );
      })}
      <div
        style={{
          position: 'absolute',
          left: '50%',
          top: '50%',
          width: size * 0.46,
          height: size * 0.46,
          marginLeft: -size * 0.23,
          marginTop: -size * 0.23,
          borderRadius: '50%',
          background: theme.gradients.gold,
          transform: `scale(${interpolate(core, [0, 1], [0.3, 1])}) scale(${1 + Math.sin(frame / 14) * 0.03})`,
        }}
      />
    </div>
  );
};
