import React from 'react';
import {Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import {sfxMeta} from '../sfxMeta';
import {sfxEvents} from '../plan';

// সংযত SFX: ভয়েসওভারের নিচে (০.২৪–০.৩০), প্রতিটি ছোট; পরপর একই সাউন্ডে সামান্য rate ভ্যারিয়েশন
export const SfxLayer: React.FC = () => {
  const {fps} = useVideoConfig();
  return (
    <>
      {sfxEvents.map((e, i) => {
        const m = sfxMeta[e.name];
        const rate = e.rate ?? 1;
        const frames = Math.ceil((m.dur / rate) * fps) + 2;
        return (
          <Sequence key={i} from={Math.max(0, e.frame)} durationInFrames={frames} layout="none">
            <Audio src={staticFile(m.file)} volume={e.vol ?? m.vol} playbackRate={rate} />
          </Sequence>
        );
      })}
    </>
  );
};
