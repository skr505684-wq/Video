// সিন ও বিটের ফ্রেম পরিকল্পনা: একবার হিসাব, সিন ও SFX দুই জায়গায় ব্যবহার।
import {segments, sceneStart, TOTAL_FRAMES, OVERLAP} from './timing';

export const S0 = segments(0, [
  'একটা কথা জানো?',
  'তোমার এই ভুলটাই তোমাকে পিছিয়ে রাখছে।',
  'তুমি ভাবছো কাল থেকে শুরু',
]);
export const S1 = segments(1, [
  'করবে। কিন্তু মনে রেখো,',
  'তোমার কাল কখনো আসবে না যদি আজ শুরু না কর।',
  'আজই শুরু কর। আর',
]);
export const S2 = segments(2, ['কথাটা সত্যি মনে হলে', 'video টা share কর।']);

export const sceneFrom = [sceneStart(0), sceneStart(1), sceneStart(2)] as const;
export const sceneDur = [
  sceneFrom[1] + OVERLAP - sceneFrom[0],
  sceneFrom[2] + OVERLAP - sceneFrom[1],
  TOTAL_FRAMES - sceneFrom[2],
] as const;

// দৃশ্য-স্থানীয় (local) বিট-ফ্রেম
export const hook = {B: S0[1].start - sceneFrom[0], C: S0[2].start - sceneFrom[0]};
export const split = {B2: S1[1].start - sceneFrom[1], B3: S1[2].start - sceneFrom[1]};
export const cta = {
  B: S2[1].start - sceneFrom[2],
  press: S2[1].speech + Math.round((S2[1].end - S2[1].speech) * 0.35) - sceneFrom[2],
};

export type SfxName = 'thud' | 'whoosh' | 'swipe' | 'pop' | 'click' | 'chime';
export type SfxEvent = {name: SfxName; frame: number; rate?: number; vol?: number};

// শুধু প্রধান এন্ট্রি, কার্ড রিভিল, সিন ট্রানজিশন ও ক্লিকে সাউন্ড
export const sfxEvents: SfxEvent[] = [
  {name: 'thud', frame: 0},
  {name: 'whoosh', frame: sceneFrom[0] + hook.B - 2},
  {name: 'pop', frame: sceneFrom[0] + hook.B + 8, rate: 1.0},
  {name: 'pop', frame: sceneFrom[0] + hook.C, rate: 1.07, vol: 0.26},
  {name: 'swipe', frame: sceneFrom[1] - 3},
  {name: 'pop', frame: sceneFrom[1] + 8, rate: 0.96},
  {name: 'click', frame: sceneFrom[1] + split.B2 + 2},
  {name: 'chime', frame: sceneFrom[1] + split.B3},
  {name: 'swipe', frame: sceneFrom[2] - 3, rate: 1.05},
  {name: 'pop', frame: sceneFrom[2] + 6, rate: 1.04},
  {name: 'click', frame: sceneFrom[2] + cta.press, rate: 1.03},
];
