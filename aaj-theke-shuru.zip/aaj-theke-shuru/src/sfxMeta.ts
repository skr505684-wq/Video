// স্বয়ংক্রিয়ভাবে তৈরি (scripts/make_sfx.py)
export const sfxMeta = {
  "pop": {
    "file": "sfx/pop.wav",
    "dur": 0.2,
    "vol": 0.3
  },
  "click": {
    "file": "sfx/click.wav",
    "dur": 0.09,
    "vol": 0.3
  },
  "whoosh": {
    "file": "sfx/whoosh.wav",
    "dur": 0.6,
    "vol": 0.24
  },
  "swipe": {
    "file": "sfx/swipe.wav",
    "dur": 0.4,
    "vol": 0.26
  },
  "chime": {
    "file": "sfx/chime.wav",
    "dur": 0.55,
    "vol": 0.24
  },
  "thud": {
    "file": "sfx/thud.wav",
    "dur": 0.35,
    "vol": 0.28
  }
} as const;
