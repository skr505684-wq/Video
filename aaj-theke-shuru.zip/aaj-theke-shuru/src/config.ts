export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজবে; না থাকলে নীরবে বাদ।
export const PREVIEW_VOICEOVER = true;
// রেন্ডার করা MP4-তে ভয়েসওভার মেশাবেন কিনা (ডিফল্ট: না)।
export const VOICEOVER_IN_RENDER = false;
