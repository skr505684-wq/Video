# আজ থেকে শুরু: Remotion মোশন গ্রাফিক্স

```
npm install
npx remotion studio
npx remotion render src/index.ts Main out/video.mp4
```

- ভয়েসওভার MP3 `public/voiceover.mp3` নামে রাখলে Studio প্রিভিউতে বাজবে (ফ্ল্যাগ: `src/config.ts`)।
- সময়ের উৎস: `public/voiceover.srt` → `npm run cues` → `src/cues.ts`।
- রং/ফন্ট/ইজিং: `src/theme.ts`। SFX: `public/sfx/` (পুনরায় বানাতে `npm run sfx`)।
